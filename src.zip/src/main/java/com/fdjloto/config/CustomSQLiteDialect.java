package com.fdjloto.config;

// Cette classe n'est plus nécessaire car nous utilisons PostgreSQL
// Vous pouvez supprimer ce fichier
