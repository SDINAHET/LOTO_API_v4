package com.fdjloto.api.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import io.jsonwebtoken.security.SignatureException;
import io.jsonwebtoken.security.WeakKeyException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * JWT Utility Class for handling JSON Web Tokens.
 * Handles generation, validation and extraction of claims.
 */
@Component
public class JwtUtils {

    private static final Logger logger = LoggerFactory.getLogger(JwtUtils.class);
    private static final String CLAIM_TOKEN_TYPE = "type";
    private static final String TOKEN_TYPE_ACCESS = "access";
    private static final String TOKEN_TYPE_REFRESH = "refresh";

    // Refresh token TTL (ex: 30 jours)
    private static final long REFRESH_TOKEN_EXP_MS = 30L * 24 * 60 * 60 * 1000;


    @Value("${app.jwtSecret}")
    private String jwtSecret;

    @Value("${app.jwtExpirationMs}")
    private long jwtExpirationMs;

    /**
     * Build signing key from application secret
     */
    private SecretKey getKey() {
        return Keys.hmacShaKeyFor(jwtSecret.getBytes(StandardCharsets.UTF_8));
    }

    /**
     * Generate JWT token for authenticated user
     */
    public String generateJwtToken(Authentication authentication) {
        List<String> roles = authentication.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .collect(Collectors.toList());

        return Jwts.builder()
                .setSubject(authentication.getName())
                .claim("roles", roles)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + jwtExpirationMs))
                .signWith(getKey())
                .compact();
    }

    /**
     * Extract username (subject) from JWT
     */
    public String getUserFromJwtToken(String token) {
        return Jwts.parser()
                .setSigningKey(getKey())
                .build()
                .parseClaimsJws(token)
                .getBody()
                .getSubject();
    }

    /**
     * Extract roles from JWT
     */
    @SuppressWarnings("unchecked")
    public List<String> getRolesFromJwtToken(String token) {
        Claims claims = Jwts.parser()
                .setSigningKey(getKey())
                .build()
                .parseClaimsJws(token)
                .getBody();

        return claims.get("roles", List.class);
    }

    /**
     * Validate JWT token signature & expiration
     */
    public boolean validateJwtToken(String token) {
        try {
            Jwts.parser()
                    .setSigningKey(getKey())
                    .build()
                    .parseClaimsJws(token);
            return true;
        } catch (SignatureException e) {
            logger.error("Invalid JWT signature", e);
        } catch (WeakKeyException e) {
            logger.error("JWT key too weak (HS512 requires long secret)", e);
        } catch (JwtException e) {
            logger.error("Invalid JWT token", e);
        }
        return false;
    }

    /**
     * @deprecated use getUserFromJwtToken instead
     */
    @Deprecated
    public String getUserNameFromJwtToken(String token) {
        return getUserFromJwtToken(token);
    }


    /**
     * Generate short-lived ACCESS token (used in Authorization header)
     */
    public String generateAccessToken(Authentication authentication) {
        return generateToken(authentication, TOKEN_TYPE_ACCESS, jwtExpirationMs);
    }

    /**
     * Generate long-lived REFRESH token (stored in HttpOnly cookie)
     */
    public String generateRefreshToken(Authentication authentication) {
        return generateToken(authentication, TOKEN_TYPE_REFRESH, REFRESH_TOKEN_EXP_MS);
    }

    /**
     * Generate access token directly from email (used after refresh)
     * Note: roles are not included here unless you fetch them from DB.
     */
    public String generateAccessTokenFromEmail(String email) {
        return Jwts.builder()
                .setSubject(email)
                .claim(CLAIM_TOKEN_TYPE, TOKEN_TYPE_ACCESS)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + jwtExpirationMs))
                .signWith(getKey())
                .compact();
    }

    /**
     * Validate refresh token (signature + expiration + type=refresh)
     */
    public boolean validateRefreshToken(String token) {
        if (!validateJwtToken(token)) {
            return false;
        }
        String type = getTokenType(token);
        return TOKEN_TYPE_REFRESH.equals(type);
    }

    /**
     * Internal token generator for access/refresh
     */
    private String generateToken(Authentication authentication, String tokenType, long expirationMs) {
        List<String> roles = authentication.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .collect(Collectors.toList());

        return Jwts.builder()
                .setSubject(authentication.getName())
                .claim("roles", roles)
                .claim(CLAIM_TOKEN_TYPE, tokenType)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + expirationMs))
                .signWith(getKey())
                .compact();
    }

    /**
     * Read claim "type" from token
     */
    private String getTokenType(String token) {
        Claims claims = Jwts.parser()
                .setSigningKey(getKey())
                .build()
                .parseClaimsJws(token)
                .getBody();

        Object type = claims.get(CLAIM_TOKEN_TYPE);
        return type != null ? type.toString() : null;
    }

}
