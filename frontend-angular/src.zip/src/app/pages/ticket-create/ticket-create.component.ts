import { Component } from '@angular/core';

@Component({
  selector: 'app-ticket-create',
  imports: [],
  templateUrl: './ticket-create.component.html',
  styleUrl: './ticket-create.component.scss'
})
export class TicketCreateComponent {

}
