import { Component } from '@angular/core';

@Component({
  selector: 'app-conditions-utilisation',
  imports: [],
  templateUrl: './conditions-utilisation.component.html',
  styleUrl: './conditions-utilisation.component.scss'
})
export class ConditionsUtilisationComponent {

}
