import { Component } from '@angular/core';

@Component({
  selector: 'app-ai',
  imports: [],
  templateUrl: './ai.component.html',
  styleUrl: './ai.component.scss'
})
export class AiComponent {

}
