import { Component } from '@angular/core';

@Component({
  selector: 'app-error-403',
  imports: [],
  templateUrl: './error-403.component.html',
  styleUrl: './error-403.component.scss'
})
export class Error403Component {

}
