import { Component } from '@angular/core';

@Component({
  selector: 'app-politique-confidentialite',
  imports: [],
  templateUrl: './politique-confidentialite.component.html',
  styleUrl: './politique-confidentialite.component.scss'
})
export class PolitiqueConfidentialiteComponent {

}
