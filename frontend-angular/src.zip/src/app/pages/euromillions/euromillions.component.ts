import { Component } from '@angular/core';

@Component({
  selector: 'app-euromillions',
  imports: [],
  templateUrl: './euromillions.component.html',
  styleUrl: './euromillions.component.scss'
})
export class EuromillionsComponent {

}
