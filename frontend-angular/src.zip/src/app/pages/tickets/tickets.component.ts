import { Component } from '@angular/core';

@Component({
  selector: 'app-tickets',
  imports: [],
  templateUrl: './tickets.component.html',
  styleUrl: './tickets.component.scss'
})
export class TicketsComponent {

}
