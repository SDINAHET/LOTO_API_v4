import { Component } from '@angular/core';

@Component({
  selector: 'app-statistiques',
  imports: [],
  templateUrl: './statistiques.component.html',
  styleUrl: './statistiques.component.scss'
})
export class StatistiquesComponent {

}
