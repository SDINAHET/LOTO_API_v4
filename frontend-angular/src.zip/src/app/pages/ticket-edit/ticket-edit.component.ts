import { Component } from '@angular/core';

@Component({
  selector: 'app-ticket-edit',
  imports: [],
  templateUrl: './ticket-edit.component.html',
  styleUrl: './ticket-edit.component.scss'
})
export class TicketEditComponent {

}
