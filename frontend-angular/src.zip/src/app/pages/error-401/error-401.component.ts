import { Component } from '@angular/core';

@Component({
  selector: 'app-error-401',
  imports: [],
  templateUrl: './error-401.component.html',
  styleUrl: './error-401.component.scss'
})
export class Error401Component {

}
